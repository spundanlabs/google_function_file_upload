
'use strict';

const process = require('process'); // Required to mock environment variables

const { format } = require('util');
const express = require('express');
const Multer = require('multer');
const bodyParser = require('body-parser');
const path = require("path");
// const app = express();
// const GoogleCloudStorage = require('@google-cloud/storage');
const { Storage } = require('@google-cloud/storage');
const GOOGLE_CLOUD_PROJECT_ID = 'node-test-254906 '; // Replace with your project ID
const GOOGLE_CLOUD_KEYFILE = './node-test-3f077228638f.json'; // Replace with the path to the downloaded private key

// Instantiate a storage client
const storage = new Storage({

    projectId: GOOGLE_CLOUD_PROJECT_ID,
    keyFilename: GOOGLE_CLOUD_KEYFILE,


});
  

const app = express();
app.use(bodyParser.json());

// Multer is required to process file uploads and make them available via
// req.files.
const multer = Multer({
    storage: Multer.memoryStorage(),
    limits: {
        fileSize: 5 * 1024 * 1024, // no larger than 5mb, you can change as needed.
    },
    fileFilter: function (req, file, callback) {

        var ext = path.extname(file.originalname);
        if (ext !== '.png' && ext !== '.jpg' && ext !== '.gif' && ext !== '.jpeg') {
            return callback(new Error('Only images are allowed'))
        }
        callback(null, true)
    }
});

// A bucket is a container for objects (files).
const bucket = storage.bucket("cool_testing");



app.get('/', (req, res) => {
    res.send('done');
})
app.post('/upload', multer.single('file'), (req, res, next) => {
    if (!req.file) {
        res.status(400).send('No file uploaded.');
        return;
    }

    // Create a new blob in the bucket and upload the file data.
    const blob = bucket.file(req.file.originalname);
    const blobStream = blob.createWriteStream();

    blobStream.on('error', err => {
        res.status(500).send(err);
    });

    blobStream.on('finish', () => {
        // The public URL can be used to directly access the file via HTTP.
        const publicUrl = format(
            `https://storage.googleapis.com/${bucket.name}/${blob.name}`
        );
        res.status(200).send(publicUrl);
    });

    blobStream.end(req.file.buffer);
});


app.get('/file/:filename', (req, res, next) => {
    var remoteFile = bucket.file(req.params.filename);
    res.setHeader("content-type", "image/*");
    remoteFile.createReadStream()
        .on('error', function (err) {
            console.log(err);
            console.log("No File Downloaded");
        })
        .on('response', function (response) {
            console.log(response);
            // Server connected and responded with the specified status and headers.
        })
        .on('end', function () {
            console.log("file downloaded");
            // The file is fully downloaded.
        })
        .pipe(res);
});
const PORT = process.env.PORT || 9000;
app.listen(PORT, () => {
    console.log(`App listening on port ${PORT}`);
    console.log('Press Ctrl+C to quit.');
});
// [END gae_flex_storage_app]

module.exports = {app}; 