# google_function_file_upload

gcloud functions deploy file-upload-01 --runtime nodejs8 --trigger-http --entry-point app

